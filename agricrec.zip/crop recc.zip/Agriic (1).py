#!/usr/bin/env python
# coding: utf-8

# In[1]:


# importing required libraries.
import pandas as pd
import numpy as np


# In[3]:


data = pd.read_csv('final_data.csv')


# In[4]:


data['crop_type'].unique()
mapping = {'carrot':1,'coconut':2,
       'cotten':3,
       'groundnut':4, 'melon':5,
       'millet':6, 'potatoes':7,
       'rice':8,
       'vegetable':9, 'wheat':10}


# In[5]:


data['crop_type'] = data['crop_type'].map(mapping)


# In[6]:


data['Soil_type'].unique()


# In[7]:


mapping = {'clay':1, 'Sandy':2,
       'loamy':3}



data['Soil_type'] = data['Soil_type'].map(mapping)


# In[8]:


X = data.drop('crop_type', axis=1).values
y = data.crop_type.values


# In[10]:


# splitting data as X_train and X_test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2,random_state = 0)
# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)




# In[11]:


#Support Vector Machines
from sklearn.svm import SVC, LinearSVC

model = SVC(C=2.0, cache_size=200, class_weight=None, coef0=0.5,
  decision_function_shape='ovr', degree=3, gamma='auto_deprecated',
  kernel='rbf', max_iter=-1, probability=False, random_state= 50,
  shrinking=True, tol=0.11, verbose=False)
model.fit(X_train,y_train)


# In[12]:


prediction_svm=model.predict(X_test)


# In[ ]:




